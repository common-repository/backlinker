<script language="Javascript" src="../wp-content/plugins/backlinker/jscolor/jscolor.js"></script>
<div class="wrap">
<div class="backwrap">
<h2>Backlinker Color Settings</h2>
<p>Use HEXCode only!</p>
  <form method="post" name="backlinker">
    <table cellpadding="6" cellspacing="8" id="backwrap">
      <tbody><tr>
          <td><label for="left_bg">Left Background</label></td>
          <td><input type="text" class="backinput {pickerPosition:'right'}" value="{left_bg}" name="left_bg"></td>
        </tr>
        <tr>
          <td><label for="left_color_txt">Left Text Color</label></td>
          <td><input type="text" class="backinput {pickerPosition:'right'}" value="{left_color_txt}" name="left_color_txt"></td>
        </tr>
        <tr>
          <td><label for="left_bg">Right Background</label></td>
          <td><input type="text" class="backinput {pickerPosition:'right'}" value="{right_bg}" name="right_bg"></td>
        </tr>
        <tr>
          <td><label for="left_color_txt">Right Text Color</label></td>
          <td><input type="text" class="backinput {pickerPosition:'right'}" value="{right_color_txt}" name="right_color_txt"></td>
        </tr>
        <tr>
          <td><label for="left_bg">Border</label></td>
          <td><input type="text" class="backinput {pickerPosition:'right'}" value="{imgborder}" name="imgborder"></td>
        </tr>
</table>
<h2>Text Settings</h2>
<table width="350" cellpadding="6" cellspacing="8" id="backwrap">
        <tr>
          <td width="116"><label for="left_txt">Left Text</label></td>
          <td><input type="text" value="{left_txt}" id="left_txt" name="left_txt"></td>
        </tr>
        <tr>
          <td><label for="right_txt">Right Text</label></td>
          <td><input type="text" value="{right_txt}" id="right_txt" name="right_txt"></td>
        </tr>
</table>

<h2>Reset Settings</h2>
<table width="350" cellpadding="6" cellspacing="8" id="backwrap">
        <tr>
          <td width="116"><label for="setdef">Reset2Default</label></td>
          <td><input type="checkbox" value="1" name="setdef"></td>
        </tr>

        <tr>
          <td width="116"><label for="setdef">Admin Test Modus</label></td>
          <td><input type="checkbox" value="1" name="testmod"></td>
        </tr>
        <tr>
          <td colspan="2" align="right"><br><br><input type="submit" value="Save Changes" class="button-primary" name="submit"></td>
        </tr>
    </tbody></table>
</form>
</div>
</div>

