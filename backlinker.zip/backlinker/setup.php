<?php
function backlinker_activate()
{
	global $wpdb;
	$current_blog_id = $wpdb->blogid;
	$tables = array("xxxx_backlinker");

	if ( $wpdb->has_cap( 'collation' ) )
	{
		if ( ! empty($wpdb->charset) )
			$charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
		if ( ! empty($wpdb->collate) )
			$charset_collate .= " COLLATE $wpdb->collate";
	}

	if(!backlinker_mysql_table_exists($tables[0]))
	{ // Add table if it's not there
		$add1 = "CREATE TABLE ".$tables[0]." (
			  `id` mediumint(8) unsigned NOT NULL,
			  `bcl` varchar(6) NOT NULL,
			  `tcl` varchar(6) NOT NULL,
			  `bcr` varchar(6) NOT NULL,
			  `tcr` varchar(6) NOT NULL,
			  `boc` varchar(6) NOT NULL,
			  `txtl` varchar(25) NOT NULL,
			  `txtr` varchar(25) NOT NULL,
	  		PRIMARY KEY  (`id`)
			) ".$charset_collate;
		if(mysql_query($add1) !== true)
		{ backlinker_mysql_warning(); }
	}
	$string2safe = BACKLINKER_DEFAULT_STRING;
    $color_data = split("[|]",$string2safe);
    @mysql_query("INSERT INTO `xxxx_backlinker` (id,bcl,tcl,bcr,tcr,boc,txtl,txtr) VALUES('$current_blog_id' ,'".$color_data[0]."' ,'".$color_data[1]."' ,'".$color_data[2]."' ,'".$color_data[3]."' ,'".$color_data[4]."' ,'".$color_data[5]."' ,'".$color_data[6]."' )");

}



function backlinker_deactivate() {
backlinker_plugin_uninstall();
}

function backlinker_mysql_table_exists($tablename) {
	global $wpdb;

	foreach ($wpdb->get_col("SHOW TABLES",0) as $table ) {
		if ($table == $tablename) {
			return true;
		}
	}
	return false;
}

function backlinker_mysql_warning() {
	echo '<div class="updated"><h3>WARNING! There was an error with MySQL! One or more queries failed. This means the database has not been created or only partly.</h3></div>';
}


function backlinker_plugin_uninstall() {
	global $wpdb;
	$current_blog_id = $wpdb->blogid;
	// Deactivate Plugin
	$current = get_settings('active_plugins');
	update_option('active_plugins', $current);
	do_action('deactivate_backlinker');

	// Drop MySQL Tables
	@mysql_query("DELETE FROM `xxxx_backlinker` WHERE id='$current_blog_id'");
	wp_redirect(get_option('siteurl').'/wp-admin/plugins.php?deactivate=true');
}
?>