<?php
// Silence is golden. Schweigen ist Gold. Callar es Oro.
?>
