<?php
/*
Plugin Name: Backlinker
Description: Free and automated Backlink from Backlinker.me
Version: 1.0.1
Author: EseLoCCo
Author URI: http://www.backlinker.me/
*/
define('BACKLINKER_VERSION', '1.0.1');
define('BACKLINKER_DEFAULT_STRING','000000|FFFFFF|FFFF00|000000|000000|Back|Link');

if(!defined('WP_PLUGIN_DIR'))
define('WP_PLUGIN_DIR', ABSPATH . 'wp-content/plugins');
if ( ! defined( 'WP_PLUGIN_URL' ) )
define( 'WP_PLUGIN_URL', WP_CONTENT_URL . '/plugins' );

$backlinker_plugin_url = WP_PLUGIN_URL . '/' .plugin_basename(dirname(__FILE__));
$backlinker_plugin_dir = WP_PLUGIN_DIR . '/' .plugin_basename(dirname(__FILE__));

include_once(ABSPATH.'wp-content/plugins/backlinker/setup.php');
include_once(ABSPATH.'wp-content/plugins/backlinker/widget.php');

register_activation_hook(__FILE__, 'backlinker_activate');
register_deactivation_hook(__FILE__, 'backlinker_deactivate');


if($_POST['left_bg'] && $_POST['left_color_txt'] && $_POST['right_bg'] && $_POST['right_color_txt'] && $_POST['imgborder'] && $_POST['left_txt'] && $_POST['right_txt'])
{
    if(!is_admin())  {
    wp_die( __('You do not have sufficient permissions to access this page.') );
    }



    if($_POST['setdef']==1)
    { $string2safe = BACKLINKER_DEFAULT_STRING; }
    else { $string2safe = strtoupper($_POST['left_bg']."|".$_POST['left_color_txt']."|".$_POST['right_bg']."|".$_POST['right_color_txt']."|".$_POST['imgborder'])."|".$_POST['left_txt']."|".$_POST['right_txt']; }
    $string2safe = str_replace("#","",$string2safe);
    $color_data = split("[|]",$string2safe);



    $current_blog_id = $wpdb->blogid;
    if(!@mysql_query("INSERT INTO `xxxx_backlinker` (id,bcl,tcl,bcr,tcr,boc,txtl,txtr) VALUES('$current_blog_id' ,'".$color_data[0]."' ,'".$color_data[1]."' ,'".$color_data[2]."' ,'".$color_data[3]."' ,'".$color_data[4]."' ,'".$color_data[5]."' ,'".$color_data[6]."' )"))
    { @mysql_query("UPDATE `xxxx_backlinker` SET bcl='".$color_data[0]."', tcl='".$color_data[1]."', bcr='".$color_data[2]."', tcr='".$color_data[3]."', boc='".$color_data[4]."', txtl='".$color_data[5]."', txtr='".$color_data[6]."' WHERE id='$current_blog_id'"); };
	if($_POST['testmod']==1)
    { add_action( 'admin_head', 'backlinker_get_code_test' ); }
    else { add_action( 'admin_head', 'backlinker_get_code_admin' ); }

}




function backlinker_get_code()
{
	global $wpdb;
    $current_blog_id = $wpdb->blogid;
	$res = @mysql_query("SELECT * FROM `xxxx_backlinker` WHERE id='$current_blog_id'");
	if(@mysql_num_rows($res)==1)
	{
	    $color_data = mysql_fetch_array($res);
        $left_bg = $color_data[1];
        $left_color_txt = $color_data[2];
        $right_bg = $color_data[3];
        $right_color_txt = $color_data[4];
        $imgborder = $color_data[5];
        $left_txt = $color_data[6];
        $right_txt = $color_data[7];
	}
	else
	    {
            $color_data = split("[|]",BACKLINKER_DEFAULT_STRING);
            $left_bg = $color_data[0];
            $left_color_txt = $color_data[1];
            $right_bg = $color_data[2];
            $right_color_txt = $color_data[3];
            $imgborder = $color_data[4];
            $left_txt = $color_data[5];
            $right_txt = $color_data[6];
        }
    $linkout = $left_bg."/".$left_color_txt."/".$right_bg."/".$right_color_txt."/".$imgborder."/".$left_txt."_".$right_txt;

$code = '<div id="backlinker"><!-- BL CODE BY http://www.backlinker.me/ START -->
<a href="http://www.backlinker.me/index.html" target="_blank" title="Kostenlose Backlinks"><img src="http://www.backlinker.me/BL'.$linkout.'.jpg" border="0" alt="Kostenlose Backlinks"></a>
<!-- BL CODE BY http://www.backlinker.me/ END --></div>';
print $code;
}

function backlinker_get_code_admin()
{
	global $wpdb;
    $current_blog_id = $wpdb->blogid;
	$res = @mysql_query("SELECT * FROM `xxxx_backlinker` WHERE id='$current_blog_id'");
	if(@mysql_num_rows($res)==1)
	{
	    $color_data = mysql_fetch_array($res);
        $left_bg = $color_data[1];
        $left_color_txt = $color_data[2];
        $right_bg = $color_data[3];
        $right_color_txt = $color_data[4];
        $imgborder = $color_data[5];
        $left_txt = $color_data[6];
        $right_txt = $color_data[7];
	}
	else
	    {
            $color_data = split("[|]",BACKLINKER_DEFAULT_STRING);
            $left_bg = $color_data[0];
            $left_color_txt = $color_data[1];
            $right_bg = $color_data[2];
            $right_color_txt = $color_data[3];
            $imgborder = $color_data[4];
            $left_txt = $color_data[5];
            $right_txt = $color_data[6];
        }
    $linkout = $left_bg."/".$left_color_txt."/".$right_bg."/".$right_color_txt."/".$imgborder."/".$left_txt."_".$right_txt;

	$code = '<div id="adminimg"><h2>Preview</h2><img src="http://www.backlinker.me/BL'.$linkout.'.jpg" border="0" alt="Kostenlose Backlinks"></div>';
	print $code;
}


function backlinker_get_code_test()
{
	global $wpdb;
    $current_blog_id = $wpdb->blogid;
	$res = @mysql_query("SELECT * FROM `xxxx_backlinker` WHERE id='$current_blog_id'");
	if(@mysql_num_rows($res)==1)
	{
	    $color_data = mysql_fetch_array($res);
        $left_bg = $color_data[1];
        $left_color_txt = $color_data[2];
        $right_bg = $color_data[3];
        $right_color_txt = $color_data[4];
        $imgborder = $color_data[5];
        $left_txt = $color_data[6];
        $right_txt = $color_data[7];
	}
	else
	    {
            $color_data = split("[|]",BACKLINKER_DEFAULT_STRING);
            $left_bg = $color_data[0];
            $left_color_txt = $color_data[1];
            $right_bg = $color_data[2];
            $right_color_txt = $color_data[3];
            $imgborder = $color_data[4];
            $left_txt = $color_data[5];
            $right_txt = $color_data[6];
        }
    $linkout = $left_bg."/".$left_color_txt."/".$right_bg."/".$right_color_txt."/".$imgborder."/".$left_txt."_".$right_txt;

	$code = '<div id="adminimg"><h2>TEST MODUS - CLICK TO CHECK</h2><a href="http://www.backlinker.me/test_index.html" target="_blank"><img src="http://www.backlinker.me/BL'.$linkout.'.jpg" border="0" alt="Kostenlose Backlinks"></a></div>';
	print $code;
}


function backgetsettings()
{

	global $backlinker_plugin_dir,$wpdb;
    $current_blog_id = $wpdb->blogid;

	$res = @mysql_query("SELECT * FROM `xxxx_backlinker` WHERE id='$current_blog_id'");
	if(@mysql_num_rows($res)==1)
	{
	    $color_data = mysql_fetch_array($res);
        $left_bg = $color_data[1];
        $left_color_txt = $color_data[2];
        $right_bg = $color_data[3];
        $right_color_txt = $color_data[4];
        $imgborder = $color_data[5];
        $left_txt = $color_data[6];
        $right_txt = $color_data[7];
	}
	else
	    {
            $color_data = split("[|]",BACKLINKER_DEFAULT_STRING);
            $left_bg = $color_data[0];
            $left_color_txt = $color_data[1];
            $right_bg = $color_data[2];
            $right_color_txt = $color_data[3];
            $imgborder = $color_data[4];
            $left_txt = $color_data[5];
            $right_txt = $color_data[6];
        }

	$c_arr = array("{left_bg}"=>$left_bg,
	"{left_color_txt}"=>$left_color_txt,
	"{right_bg}"=>$right_bg,
	"{right_color_txt}"=>$right_color_txt,
	"{imgborder}"=>$imgborder,
	"{left_txt}"=>$left_txt,
	"{right_txt}"=>$right_txt);

	$fp = fopen($backlinker_plugin_dir."/options.php","r");
	$tmp = fread($fp,8000);
	fclose($fp);

	if(is_array($c_arr))
    {
        foreach( $c_arr as $id => $value )
        { $tmp = str_replace( $id, $value, $tmp ); }
	};
	print $tmp;
}


function filter_backlinker_actions($links, $file)
{
$settings_link = '<a href="options-general.php?page=backgen">' . __('Settings') . '</a>';
array_unshift( $links, $settings_link ); // before other links

return $links;
}



function backlinker_load_styles(){
global $backlinker_plugin_url;
$css_url = $backlinker_plugin_url . '/backlinker.css';
wp_register_style('backlinker', $css_url, array(), BACKLINKER_VERSION, 'screen');
wp_enqueue_style('backlinker');
}


function backlinker_settings()
{
	add_options_page('Backlinker Settings', 'Backlinker', 'manage_options', 'backgen', 'backgetsettings');
}




if ( is_admin() )
{
	add_action('admin_print_styles', 'backlinker_load_styles');
	add_action('admin_menu', 'backlinker_settings');
	add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'filter_backlinker_actions', 10, 2 );
}
else
{
	add_action('wp_print_styles', 'backlinker_load_styles');
	if(!is_active_widget(false, false, "m_backlinker", true))
	{
		if(!wp_footer()){ add_action('wp_head', 'backlinker_get_code'); }
    	else { add_action('wp_footer', 'backlinker_get_code'); }
    }
}