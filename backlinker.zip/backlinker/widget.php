<?php
class m_widget_backlinker extends WP_Widget
{

		/** constructor **/
		function m_widget_backlinker() {
			parent::WP_Widget(false, $name = 'Backlinker');
		}

		/** This function displays the output of the widget **/
		function widget($args, $instance)
		{
			global $wpdb,$backlinker_plugin_url;
            extract( $args );
			$option = $instance;
			$title = empty($options['title']) ? __('Backlinker') : apply_filters('widget_title', $options['title']);

            $current_blog_id = $wpdb->blogid;
            $res = @mysql_query("SELECT * FROM `xxxx_backlinker` WHERE id='$current_blog_id'");
            if(@mysql_num_rows($res)==1)
            {
                $color_data = mysql_fetch_array($res);
                $left_bg = $color_data[1];
                $left_color_txt = $color_data[2];
                $right_bg = $color_data[3];
                $right_color_txt = $color_data[4];
                $imgborder = $color_data[5];
                $left_txt = $color_data[6];
                $right_txt = $color_data[7];
            }
            else
                {
                    $color_data = split("[|]",BACKLINKER_DEFAULT_STRING);
                    $left_bg = $color_data[0];
                    $left_color_txt = $color_data[1];
                    $right_bg = $color_data[2];
                    $right_color_txt = $color_data[3];
                    $imgborder = $color_data[4];
                    $left_txt = $color_data[5];
                    $right_txt = $color_data[6];
                }
            $linkout = $left_bg."/".$left_color_txt."/".$right_bg."/".$right_color_txt."/".$imgborder."/".$left_txt."_".$right_txt;

            $code = '<link rel="stylesheet" type="text/css" href="'.$backlinker_plugin_url.'/widget_style.css" media="screen" />
            <div id="backwidget"><!-- BL CODE BY http://www.backlinker.me/ START -->
            <a href="http://www.backlinker.me/index.html" target="_blank" title="Kostenlose Backlinks"><img src="http://www.backlinker.me/BL'.$linkout.'.jpg" border="0" alt="Kostenlose Backlinks"></a>
            <!-- BL CODE BY http://www.backlinker.me/ END --></div>';
            print $code;
		}
}

	add_action('widgets_init', create_function('', 'return register_widget("m_widget_backlinker");'));
?>